package handmadeguns2.block;

import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityLockable;
import net.minecraft.util.ITickable;

public class TileEntity_Crafter2E extends TileEntity implements ITickable
{
	
	public int gun_select = 0;
	
	
	
	public void update()
    {
		
    }
}
