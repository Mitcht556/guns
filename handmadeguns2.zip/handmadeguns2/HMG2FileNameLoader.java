package handmadeguns2;

public class HMG2FileNameLoader {
	public static String load(int id) {
		String s = "";
		if(id == 0) {
			s = "0";
		}
		else if(id == 1) {
			s = "1";
		}
		else if(id == 2) {
			s = "2";
		}
		else if(id == 3) {
			s = "3";
		}
		else if(id == 4) {
			s = "4";
		}
		else if(id == 5) {
			s = "5";
		}
		else if(id == 6) {
			s = "6";
		}
		else if(id == 7) {
			s = "7";
		}
		else if(id == 8) {
			s = "8";
		}
		else if(id == 9) {
			s = "9";
		}
		else if(id == 10) {
			s = "";
		}
		
		else if(id == 11) {
			s = "a";
		}
		else if(id == 12) {
			s = "b";
		}
		else if(id == 13) {
			s = "c";
		}
		else if(id == 14) {
			s = "d";
		}
		else if(id == 15) {
			s = "e";
		}
		else if(id == 16) {
			s = "f";
		}
		else if(id == 17) {
			s = "g";
		}
		else if(id == 18) {
			s = "h";
		}
		else if(id == 19) {
			s = "i";
		}
		else if(id == 20) {
			s = "j";
		}
		else if(id == 21) {
			s = "k";
		}
		else if(id == 22) {
			s = "l";
		}
		else if(id == 23) {
			s = "m";
		}
		else if(id == 24) {
			s = "n";
		}
		else if(id == 25) {
			s = "o";
		}
		else if(id == 26) {
			s = "p";
		}
		else if(id == 27) {
			s = "q";
		}
		else if(id == 28) {
			s = "r";
		}
		else if(id == 29) {
			s = "s";
		}
		else if(id == 30) {
			s = "t";
		}
		else if(id == 31) {
			s = "u";
		}
		else if(id == 32) {
			s = "v";
		}
		else if(id == 33) {
			s = "w";
		}
		else if(id == 34) {
			s = "x";
		}
		else if(id == 35) {
			s = "y";
		}
		else if(id == 36) {
			s = "z";
		}
		else if(id == 37) {
			s = "_";
		}
		
		
		return s;
	}
}
